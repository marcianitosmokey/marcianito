(() => {
  "use strict";

  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];

  // -------------------------
  // Basic state
  // -------------------------
  const state = {
    lang: localStorage.getItem("marcianito-lang") || "es",
    theme: localStorage.getItem("marcianito-theme") || "dark",
    sound: localStorage.getItem("marcianito-sound") !== "off"
  };

  const translations = {
    es: {
      navAbout:"sobre mí", navSocial:"redes", navBots:"bots", navMusic:"música", navTarot:"tarot", navWall:"muro",
      status:"transmission online",
      heroSub:"un pequeño rincón del internet donde guardo mis mundos, mis bots, mi música y otras rarezas.",
      enter:"entrar al portal", random:"sorpréndeme",
      aboutTitle:"¿quién es el marciano?", aboutHead:"hola, soy Marcianito.",
      aboutText:"Soy una criatura de internet a la que le gusta crear cosas: bots, páginas, ideas raras, tarot y pequeños universos digitales. Estudio, programo a mi manera y siempre termino abriendo otra pestaña.",
      micro:"si llegaste hasta aquí, probablemente ya eres parte del lore.",
      socialTitle:"mis redes", botsTitle:"mis bots",
      botOne:"una de mis estaciones de bots.", botTwo:"un personaje perdido entre ventanas.",
      botThree:"otro rincón donde viven mis bots.", botFour:"otra señal recibida.", botFive:"una estación más del universo Marcianito.",
      musicTitle:"mi música", musicHead:"pon algo de ruido.",
      musicText:"Aquí puedes reproducir directamente mis playlists desde Spotify.",
      tarotTitle:"tarot", tarotHead:"una lectura, una pregunta.",
      tarotText:"Explora una lectura de tarot desde mi pequeño rincón. Las cartas pueden servir como herramienta de reflexión y entretenimiento.",
      draw:"sacar una carta", drawHint:"pulsa el botón", drawHint2:"y deja que el sistema elija una carta.",
      wallTitle:"muro de mensajes", nameLabel:"nombre / alias", messageLabel:"mensaje",
      anonLabel:"publicar como anónimo", send:"transmitir",
      wallNote:"Nota: esta versión guarda los mensajes en el navegador de cada visitante. Para un muro público compartido necesitaremos conectar una base de datos/servicio externo.",
      eggText:"Psst... hay cosas escondidas aquí.",
      footerText:"made somewhere between earth & the internet."
    },
    en: {
      navAbout:"about", navSocial:"socials", navBots:"bots", navMusic:"music", navTarot:"tarot", navWall:"wall",
      status:"transmission online",
      heroSub:"a tiny corner of the internet where I keep my worlds, bots, music and other strange things.",
      enter:"enter the portal", random:"surprise me",
      aboutTitle:"who is the alien?", aboutHead:"hi, i'm Marcianito.",
      aboutText:"I'm an internet creature who likes making things: bots, pages, weird ideas, tarot and tiny digital universes. I study, code my own way, and somehow always end up opening another tab.",
      micro:"if you made it this far, you're probably part of the lore now.",
      socialTitle:"my socials", botsTitle:"my bots",
      botOne:"one of my bot stations.", botTwo:"a character lost between windows.",
      botThree:"another place where my bots live.", botFour:"another signal received.", botFive:"one more station in the Marcianito universe.",
      musicTitle:"my music", musicHead:"make some noise.",
      musicText:"Play my Spotify playlists directly from here.",
      tarotTitle:"tarot", tarotHead:"one reading, one question.",
      tarotText:"Explore a tarot reading from my little corner. Cards can be used as a tool for reflection and entertainment.",
      draw:"draw a card", drawHint:"press the button", drawHint2:"and let the system choose a card.",
      wallTitle:"message wall", nameLabel:"name / alias", messageLabel:"message",
      anonLabel:"post anonymously", send:"transmit",
      wallNote:"Note: this version stores messages in each visitor's browser. A shared public wall needs a database/external service connected to the site.",
      eggText:"Psst... there are hidden things around here.",
      footerText:"made somewhere between earth & the internet."
    }
  };

  function applyLanguage() {
    const dict = translations[state.lang];
    $$("[data-i18n]").forEach(el => {
      const key = el.dataset.i18n;
      if (dict[key]) el.textContent = dict[key];
    });
    $("#langBtn").textContent = state.lang.toUpperCase();
    document.documentElement.lang = state.lang;
    localStorage.setItem("marcianito-lang", state.lang);
  }

  function applyTheme() {
    document.body.classList.toggle("alt-theme", state.theme === "aero");
    $("#themeBtn").textContent = state.theme === "aero" ? "☼" : "◐";
    localStorage.setItem("marcianito-theme", state.theme);
  }

  function applySoundUI() {
    $("#soundBtn").textContent = state.sound ? "♫" : "♩";
    localStorage.setItem("marcianito-sound", state.sound ? "on" : "off");
  }

  // -------------------------
  // Tiny click sounds with Web Audio.
  // Browsers require user interaction before audio can play.
  // -------------------------
  let audioCtx = null;
  function blip(freq = 520, duration = 0.055, type = "sine") {
    if (!state.sound) return;
    try {
      audioCtx ||= new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === "suspended") audioCtx.resume();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = type;
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.045, audioCtx.currentTime + 0.008);
      gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);
      osc.connect(gain).connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + duration + 0.01);
    } catch (_) {}
  }

  function addRipple(el, e) {
    if (!el || !el.getBoundingClientRect) return;
    const rect = el.getBoundingClientRect();
    const r = document.createElement("span");
    r.className = "ripple";
    const size = Math.max(rect.width, rect.height) * 1.3;
    r.style.width = r.style.height = `${size}px`;
    r.style.left = `${(e?.clientX ?? rect.left + rect.width/2) - rect.left - size/2}px`;
    r.style.top = `${(e?.clientY ?? rect.top + rect.height/2) - rect.top - size/2}px`;
    el.appendChild(r);
    setTimeout(() => r.remove(), 650);
  }

  // -------------------------
  // Terminal animation
  // -------------------------
  const terminalLines = [
    "connecting to strange little universe...",
    "loading tiny alien...",
    "opening 47 unnecessary tabs...",
    "finding lost GIFs...",
    "signal stable. welcome.",
    "you were not supposed to find this.",
  ];
  let lineIndex = 0;
  let charIndex = 0;
  let deleting = false;
  const terminal = $("#terminalText");

  function terminalLoop() {
    if (!terminal) return;
    const word = terminalLines[lineIndex];
    if (!deleting) {
      terminal.textContent = word.slice(0, ++charIndex);
      if (charIndex >= word.length) {
        deleting = true;
        setTimeout(terminalLoop, 1500);
        return;
      }
    } else {
      terminal.textContent = word.slice(0, --charIndex);
      if (charIndex <= 0) {
        deleting = false;
        lineIndex = (lineIndex + 1) % terminalLines.length;
      }
    }
    setTimeout(terminalLoop, deleting ? 35 : 45);
  }
  terminalLoop();

  // -------------------------
  // Cursor glow
  // -------------------------
  const glow = $("#cursorGlow");
  window.addEventListener("pointermove", e => {
    if (glow) {
      glow.style.left = `${e.clientX}px`;
      glow.style.top = `${e.clientY}px`;
    }
  }, {passive:true});

  // -------------------------
  // Sound + ripples
  // -------------------------
  $$("[data-sound]").forEach(el => {
    el.addEventListener("click", e => {
      blip(500 + Math.random() * 250, .05);
      addRipple(el, e);
    });
  });

  $("#soundBtn").addEventListener("click", () => {
    state.sound = !state.sound;
    applySoundUI();
    if (state.sound) blip(760, .08);
    toast(state.sound ? "sound: ON" : "sound: OFF");
  });

  $("#langBtn").addEventListener("click", () => {
    state.lang = state.lang === "es" ? "en" : "es";
    applyLanguage();
    blip(650, .07);
    toast(state.lang === "es" ? "idioma: español" : "language: english");
  });

  $("#themeBtn").addEventListener("click", () => {
    state.theme = state.theme === "dark" ? "aero" : "dark";
    applyTheme();
    blip(420, .08, "triangle");
    toast(state.theme === "aero" ? "theme: aero" : "theme: dark");
  });

  // -------------------------
  // Random portal
  // -------------------------
  const randomTargets = ["#sobre", "#redes", "#bots", "#musica", "#tarot", "#muro"];
  $("#randomBtn").addEventListener("click", () => {
    const target = randomTargets[Math.floor(Math.random() * randomTargets.length)];
    blip(720, .07, "square");
    document.querySelector(target)?.scrollIntoView({behavior:"smooth", block:"start"});
    toast(`signal redirected → ${target.replace("#","")}`);
  });

  // -------------------------
  // Tabs counter
  // -------------------------
  const tabsCount = $("#tabsCount");
  let fakeTabs = 7;
  setInterval(() => {
    fakeTabs = Math.min(99, fakeTabs + (Math.random() > .7 ? 1 : 0));
    if (tabsCount) tabsCount.textContent = fakeTabs > 20 ? "∞" : fakeTabs;
  }, 4200);

  // -------------------------
  // Tarot mini-draw
  // -------------------------
  const cards = [
    {es:["El Sol","claridad, alegría y energía para avanzar","☀"],en:["The Sun","clarity, joy and energy to move forward","☀"]},
    {es:["La Luna","intuición, sueños y cosas que todavía no ves con claridad","☾"],en:["The Moon","intuition, dreams and things you cannot see clearly yet","☾"]},
    {es:["La Estrella","esperanza, creatividad y una señal para seguir creando","✦"],en:["The Star","hope, creativity and a sign to keep creating","✦"]},
    {es:["El Mago","iniciativa, recursos y ganas de convertir una idea en algo real","✧"],en:["The Magician","initiative, resources and the drive to turn an idea into something real","✧"]},
    {es:["La Rueda","cambios, ciclos y una nueva vuelta del universo","◉"],en:["Wheel of Fortune","change, cycles and another turn of the universe","◉"]},
    {es:["El Ermitaño","pausa, reflexión y escuchar tu propia señal","☵"],en:["The Hermit","pause, reflection and listening to your own signal","☵"]}
  ];

  $("#drawCard").addEventListener("click", () => {
    const data = cards[Math.floor(Math.random() * cards.length)][state.lang];
    const card = $("#drawnCard");
    $(".card-symbol", card).textContent = data[2];
    $("h3", card).textContent = data[0];
    $("p", card).textContent = data[1];
    card.classList.remove("revealed");
    void card.offsetWidth;
    card.classList.add("revealed");
    blip(300,.08,"triangle");
    setTimeout(() => blip(520,.1,"sine"), 100);
  });

  // -------------------------
  // Guestbook: local-only by design.
  // Text is rendered through textContent to avoid HTML injection.
  // -------------------------
  const STORAGE_KEY = "marcianito-guestbook-v1";
  const form = $("#guestForm");
  const list = $("#messagesList");
  const count = $("#messageCount");

  function loadMessages() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
    catch (_) { return []; }
  }

  function saveMessages(messages) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(messages.slice(0, 40)));
  }

  function renderMessages() {
    const messages = loadMessages();
    list.innerHTML = "";
    count.textContent = messages.length;
    if (!messages.length) {
      const empty = document.createElement("p");
      empty.className = "microcopy";
      empty.textContent = state.lang === "es" ? "todavía no hay señales. sé la primera." : "no signals yet. be the first.";
      list.appendChild(empty);
      return;
    }
    messages.forEach(m => {
      const article = document.createElement("article");
      article.className = "message";
      const meta = document.createElement("div");
      meta.className = "message-meta";
      const name = document.createElement("span");
      name.textContent = m.name;
      const date = document.createElement("time");
      date.textContent = new Date(m.time).toLocaleDateString(state.lang === "es" ? "es-MX" : "en-US");
      meta.append(name, date);
      const p = document.createElement("p");
      p.textContent = m.message;
      article.append(meta,p);
      list.appendChild(article);
    });
  }

  form.addEventListener("submit", e => {
    e.preventDefault();
    const nameInput = $("#guestName");
    const msgInput = $("#guestMessage");
    const anon = $("#anonymous").checked;
    const message = msgInput.value.trim();
    if (!message) return;

    const name = anon ? (state.lang === "es" ? "anónimo" : "anonymous") : (nameInput.value.trim() || "guest");
    const messages = loadMessages();
    messages.unshift({name, message, time: Date.now()});
    saveMessages(messages);
    form.reset();
    $("#anonymous").checked = true;
    renderMessages();
    blip(780,.08,"square");
    toast(state.lang === "es" ? "señal transmitida." : "signal transmitted.");
  });

  // -------------------------
  // Easter egg
  // -------------------------
  const secret = $("#secretOverlay");
  $("#eggBtn").addEventListener("click", () => {
    secret.classList.add("open");
    secret.setAttribute("aria-hidden","false");
    blip(190,.12,"sawtooth");
    setTimeout(() => blip(90,.12,"sawtooth"), 130);
  });
  $("#closeSecret").addEventListener("click", closeSecret);
  secret.addEventListener("click", e => { if (e.target === secret) closeSecret(); });
  function closeSecret() {
    secret.classList.remove("open");
    secret.setAttribute("aria-hidden","true");
  }

  // Konami-style secret
  const secretKeys = ["ArrowUp","ArrowUp","ArrowDown","ArrowDown","ArrowLeft","ArrowRight","ArrowLeft","ArrowRight","b","a"];
  let secretPos = 0;
  window.addEventListener("keydown", e => {
    if (e.key === secretKeys[secretPos]) {
      secretPos++;
      if (secretPos === secretKeys.length) {
        secretPos = 0;
        secret.classList.add("open");
        blip(900,.1,"square");
      }
    } else {
      secretPos = 0;
    }
  });

  // -------------------------
  // Matrix mode
  // -------------------------
  $("#matrixBtn").addEventListener("click", () => {
    document.body.classList.toggle("matrix");
    blip(260,.1,"sawtooth");
    toast(document.body.classList.contains("matrix") ? "MATRIX MODE // ON" : "MATRIX MODE // OFF");
  });

  // -------------------------
  // Generic toast
  // -------------------------
  let toastTimer;
  function toast(message) {
    const t = $("#toast");
    t.textContent = message;
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove("show"), 1900);
  }

  // -------------------------
  // Init
  // -------------------------
  applyLanguage();
  applyTheme();
  applySoundUI();
  renderMessages();
  $("#year").textContent = new Date().getFullYear();

  // Random rotations for chaos gallery
  $$(".gallery-chaos img").forEach((img,i) => {
    img.style.setProperty("--r", `${(i % 2 ? -1 : 1) * (1 + (i % 3))}deg`);
  });

  // Reveal-on-scroll effect without extra libraries
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.animate(
          [{opacity:0, transform:"translateY(20px)"},{opacity:1, transform:"translateY(0)"}],
          {duration:650, easing:"cubic-bezier(.2,.7,.2,1)", fill:"both"}
        );
        observer.unobserve(entry.target);
      }
    });
  }, {threshold:.08});
  $$(".panel,.portal-card,.bot-card,.spotify-card,.drawn-card,.easter-card").forEach(el => observer.observe(el));

})();
