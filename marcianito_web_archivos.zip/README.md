# MARCIANITO.EXE

Archivos principales:
- index.html
- estilo.css
- script.js

Todos los nombres de imágenes usados en el código corresponden a los nombres mostrados en el repositorio.

## GitHub Pages
Sube/reemplaza los tres archivos en la raíz del repositorio y activa GitHub Pages desde:
Settings → Pages → Deploy from a branch → principal → /(root) → Save.

## Importante sobre el muro de mensajes
La versión incluida guarda mensajes en `localStorage`, por lo que cada visitante ve sus propios mensajes. Para que todos puedan ver los mismos mensajes y publicar de forma anónima, hace falta conectar un backend/base de datos (por ejemplo, Supabase/Firebase o un endpoint propio). No se incluye una clave privada en el frontend.
